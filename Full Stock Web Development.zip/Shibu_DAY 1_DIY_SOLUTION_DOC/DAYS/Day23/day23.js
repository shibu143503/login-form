// function change(){
//     const element =document.getElementById('head');
//     element.style.color='red';
//     element.parentNode.style.backgroundColor='sky blue';
// }
// const formSubmited=function (){
//     const ele = document.getElementById("mobNum");
//     const val=ele.value;
//     //validate for 10 digits -India
//     if (val.length !=10){
//         alert("Invalid Mobile Number");
//     }else{
//         alert("valid Mobile Number");

//     }}

function Address(){
    const element=document.getElementById("add");
    element.style.color='green';
}
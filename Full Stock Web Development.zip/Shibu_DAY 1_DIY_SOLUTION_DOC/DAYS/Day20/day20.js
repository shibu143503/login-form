const newString="let's slice is string";
var sliceString=newString.slice(15);
console.log(sliceString);

let text1 = "Today is a Dummy day";
let result1 = text1.replace("Dummy", "Grate");
console.log(result1)


let text = "Today is a Grate day";
let result = text.replace("Today is a Grate day", function (x) {
  return x.toUpperCase();
});
console.log(result);
var text =0;
var number =20;
var h1 =25;
var h2 =30;
var sentence = "Hello world";
var h3 = true;

console.log(text,number,h1,h2)
console.log(sentence)
console.log(h3)
var a =15;
console.log(a)
var b = -5;
console.log(b)
var c = 50;
console.log(c)
var d = 0.5;
console.log(d)
 var e = 5;
console.log(e)
var f = false;
 console.log(f)
 var g = true;
 console.log(g)
 var h = true;
 console.log(h)
 var i = false;
 console.log(i)
 var j = true;
 console.log(j)
 var k = true;
 console.log(k)
 var l = false;
 console.log(l)
 var m = false;
 console.log(m)
 var n = true;
 console.log(n)
 var o = true;
 console.log(o)
 var p = false;
 console.log(p)
var q = 123;
 var r = 456;
 console.log(q,r)
 var s =128;
console.log(s)
var t = 456;
console.log(t)
var u = 126;
console.log(u)
var v = 'world';
console.log(v)
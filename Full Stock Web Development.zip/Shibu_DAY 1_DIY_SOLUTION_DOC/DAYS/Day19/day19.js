 var x=10;
 var y=20;
 if(x<y){
    console.log('y is grater than x');
 }else{
    console.log('x is grater than y');
 }

 switch(y) {
    case 20:
      // code block
      console.log("hello from case one");
      break;
    case 10:
      // code block
      console.log("hello from case two");
      break;
    default:
      // code block
  }


  let k = 1;
  let sum = 0;
  while(k<=10){
    sum =sum + 10;
    k +=1;
  }
  console.log(sum);
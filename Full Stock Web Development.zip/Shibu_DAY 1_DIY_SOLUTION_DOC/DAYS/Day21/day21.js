let array=[1,2,3];
array.push(4);
console.log(array);

array.pop();
console.log(array);

array.shift();
console.log(array);

array.unshift(5);
console.log(array);


let array2= []
  var person = {
    name:"rahul",
    empId:27,
  };
 var  person1={
    email:"mailme@gmail.com",
   
      };
 var  address={
    cityName :'Vijayawada',

};
var city={name: 'Ravi', empId: 9867,mailId: 'ravimail@gmail.com', Address: {'City  Name':  'Guntur',  District:  'Prakasham  district', Pin: 685479,},Hobbies: ['Reading', 'Swimming', 'Baking'],};

console.log(address);
console.log(person);
console.log(person1);
console.log(city);


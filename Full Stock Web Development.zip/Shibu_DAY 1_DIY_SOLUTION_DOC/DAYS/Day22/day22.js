var restarentList=[
    {
        id:1,
        restarentName:"KFC",
        address:"Anand Vihar",
        city:"delhi",
    },
    {
        id:2,
        restarentName:"Domino",
        address:"Savita vihar",
        city:"delhi",
    },
    {
        id:3,
        restarentName:"Burger kink",
        address:"Civil Lines",
        city:"pune",
    },
    {
        id:4,
        restarentName:"Subway",
        address:"cantinment",
        city:"Mumbai",
    },


];
console.log(restarentList)

const d = new Date();
console.log(d)
console.log( d.getDate());
console.log( d.getMonth());
console.log( d.getFullYear());
console.log( d.getTime());
console.log( d.getHours());

//MATH METHORD

var x=20;
console.log(Math.sqrt(x));
console.log(Math.pow(x));
console.log(Math.PI);
console.log(Math.E );
console.log(Math.SQRT2);
console.log(Math.SQRT1_2);
console.log(Math.LN2 );
console.log(Math.LN10);
console.log(Math.LOG2E);
console.log(Math.LOG10E(x));
